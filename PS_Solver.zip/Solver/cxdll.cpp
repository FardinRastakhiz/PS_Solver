// cxdll.cpp : Defines the exported functions for the DLL.
//
#define _CRT_SECURE_NO_WARNINGS
#include "pch.h"
#include "framework.h"
#include "cxdll.h"
#include <iostream>
#include <omp.h>
#include "./Eigen/Eigen"
#include <fstream>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <chrono>
#include <future>
#include <ctype.h>
using namespace std;
using namespace std::chrono;
typedef Eigen::Triplet<double> T;
const string X_FILE_NAME = "X";


void fill_triplet(vector<T>& tripletList , int numNonzero, int* rowIndices, int* colIndices, double* values) {
    auto start = high_resolution_clock::now();
    tripletList.reserve(numNonzero);
    for (int i = 0; i < numNonzero;i++)
    {
        tripletList.push_back(T(rowIndices[i] - 1, colIndices[i] - 1, values[i]));
    }
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by Reader: "
        << duration.count() << " microseconds" << endl;
}



void fill_vector(Eigen::VectorXd& B , int numRows , double* rhs) { //here rhs means right hand side
    for (int i = 0; i < numRows; i++)
    {
        B(i) = rhs[i];
    }
}

Eigen::VectorXd solve(Eigen::SparseMatrix<double>& A, Eigen::VectorXd& B , int numRows) {
    auto start = high_resolution_clock::now();
    Eigen::VectorXd x(numRows);
    Eigen::initParallel();
    int m = 8;
    omp_set_num_threads(m);
    Eigen::setNbThreads(m);
    Eigen::ConjugateGradient<Eigen::SparseMatrix<double> > solver;
    solver.analyzePattern(A);
    solver.factorize(A);
    x = solver.solve(B);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by solver: "
        << duration.count() << " microseconds" << endl;
    return x;

}
void write_to_file(Eigen::VectorXd X) {
    std::ofstream file(X_FILE_NAME);
    if (file.is_open())
    {
        for (int i = 0; i < X.size(); i++) {
            file << X[i] << endl;
        }
    }
}


    // This is an example of an exported function.
    CXDLL_API void solve_matrix(int numRows, int numNonzero, int* rowIndices, int* colIndices, double* values, double* rhs, double* result) {
        int n = numRows;
        cout << "Reading A ..." << endl;
        Eigen::VectorXd B(n);
        Eigen::SparseMatrix<double> A(n, n);
        std::vector<T> tripletList;
        fill_triplet(tripletList ,numNonzero,rowIndices,colIndices,values);
        A.setFromTriplets(tripletList.begin(), tripletList.end());
        A.makeCompressed();
        cout << "Reading A Finished" << endl;
        cout << "Reading B ..." << endl;
        fill_vector(B,  numRows , rhs);
        cout << "Reading B Finished" << endl;
        cout << "Solving ..." << endl;
        Eigen::VectorXd X = solve(A, B , numRows);
        write_to_file(X);

    }





